-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.20 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица kodix.kodix_brand
CREATE TABLE IF NOT EXISTS `kodix_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Бренды';

-- Дамп данных таблицы kodix.kodix_brand: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `kodix_brand` DISABLE KEYS */;
INSERT IGNORE INTO `kodix_brand` (`id`, `name`) VALUES
	(1, 'Toyota'),
	(2, 'Mazda'),
	(3, 'Subaru'),
	(4, 'Ford');
/*!40000 ALTER TABLE `kodix_brand` ENABLE KEYS */;

-- Дамп структуры для таблица kodix.kodix_car
CREATE TABLE IF NOT EXISTS `kodix_car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `year` int(4) NOT NULL DEFAULT '0',
  `price` double unsigned NOT NULL DEFAULT '0',
  `set_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Автомобили';

-- Дамп данных таблицы kodix.kodix_car: ~19 rows (приблизительно)
/*!40000 ALTER TABLE `kodix_car` DISABLE KEYS */;
INSERT IGNORE INTO `kodix_car` (`id`, `name`, `year`, `price`, `set_id`) VALUES
	(1, 'Автомобиль', 2015, 900000, 1),
	(2, 'Машина', 2010, 1000000, 2),
	(3, 'Втмбль', 2014, 830000, 1),
	(4, 'Форд Фокус', 2005, 500000, 3),
	(5, 'Форд Фокус', 2014, 700000, 4),
	(6, 'Форд Фокус', 1999, 900000, 3),
	(7, 'Форд Фокус', 2017, 500000, 5),
	(8, 'Форд Фокус', 2019, 120000, 5),
	(9, 'Форд Фокус', 2006, 500000, 3),
	(10, 'Форд Фокус', 2008, 500000, 4),
	(11, 'Форд Фокус', 2005, 830000, 3),
	(12, 'Форд Фокус', 2007, 500000, 3),
	(13, 'Форд Фокус', 2009, 650000, 5),
	(14, 'Форд Фокус', 2011, 734000, 4),
	(15, 'Форд Фокус', 2016, 933000, 3),
	(16, 'Форд Фокус', 2019, 500000, 5),
	(17, 'Форд Фокус', 2015, 860000, 3),
	(18, 'Форд Фокус', 2017, 700000, 3),
	(19, 'Форд Фокус', 2004, 500000, 4);
/*!40000 ALTER TABLE `kodix_car` ENABLE KEYS */;

-- Дамп структуры для таблица kodix.kodix_model
CREATE TABLE IF NOT EXISTS `kodix_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Модели';

-- Дамп данных таблицы kodix.kodix_model: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `kodix_model` DISABLE KEYS */;
INSERT IGNORE INTO `kodix_model` (`id`, `name`, `brand_id`) VALUES
	(1, 'Impreza', 3),
	(2, '323F', 2),
	(3, '626', 2),
	(4, 'Focus', 4);
/*!40000 ALTER TABLE `kodix_model` ENABLE KEYS */;

-- Дамп структуры для таблица kodix.kodix_option
CREATE TABLE IF NOT EXISTS `kodix_option` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Опции';

-- Дамп данных таблицы kodix.kodix_option: ~6 rows (приблизительно)
/*!40000 ALTER TABLE `kodix_option` DISABLE KEYS */;
INSERT IGNORE INTO `kodix_option` (`id`, `name`) VALUES
	(1, 'ГУР'),
	(2, 'Центральный замок'),
	(3, 'Кондиционер'),
	(4, 'Магнитола'),
	(5, 'Сигнализация'),
	(6, '17-дюймовые диски'),
	(7, 'Коврики');
/*!40000 ALTER TABLE `kodix_option` ENABLE KEYS */;

-- Дамп структуры для таблица kodix.kodix_option_car
CREATE TABLE IF NOT EXISTS `kodix_option_car` (
  `option` int(11) DEFAULT NULL,
  `car` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Дамп данных таблицы kodix.kodix_option_car: ~16 rows (приблизительно)
/*!40000 ALTER TABLE `kodix_option_car` DISABLE KEYS */;
INSERT IGNORE INTO `kodix_option_car` (`option`, `car`) VALUES
	(1, 1),
	(1, 2),
	(2, 2),
	(7, 5),
	(7, 6),
	(7, 7),
	(7, 8),
	(7, 9),
	(7, 10),
	(7, 11),
	(7, 12),
	(7, 13),
	(7, 14),
	(7, 15),
	(7, 16),
	(7, 4),
	(7, 17),
	(7, 18);
/*!40000 ALTER TABLE `kodix_option_car` ENABLE KEYS */;

-- Дамп структуры для таблица kodix.kodix_option_set
CREATE TABLE IF NOT EXISTS `kodix_option_set` (
  `option` int(11) NOT NULL,
  `set` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Дамп данных таблицы kodix.kodix_option_set: ~6 rows (приблизительно)
/*!40000 ALTER TABLE `kodix_option_set` DISABLE KEYS */;
INSERT IGNORE INTO `kodix_option_set` (`option`, `set`) VALUES
	(1, 1),
	(2, 1),
	(4, 4),
	(4, 5),
	(5, 4),
	(5, 5),
	(6, 5);
/*!40000 ALTER TABLE `kodix_option_set` ENABLE KEYS */;

-- Дамп структуры для таблица kodix.kodix_set
CREATE TABLE IF NOT EXISTS `kodix_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Комплектации';

-- Дамп данных таблицы kodix.kodix_set: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `kodix_set` DISABLE KEYS */;
INSERT IGNORE INTO `kodix_set` (`id`, `name`, `model_id`) VALUES
	(1, 'Базовая', 1),
	(2, 'Полная', 2),
	(3, 'Ambiente', 4),
	(4, 'Trend', 4),
	(5, 'Titanium', 4);
/*!40000 ALTER TABLE `kodix_set` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
